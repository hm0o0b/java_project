package com11.member.main;

import com.member.controller.Admin;

public class DisplayAdmin11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Admin ad = new Admin();
		ad.adminLogin();
		ad.showMenu();
	}
}
